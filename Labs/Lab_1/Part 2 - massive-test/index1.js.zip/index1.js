var express = require('express');
var app = express();
var Massive=require("massive");
var db = Massive.connectSync({db : "pgguide"});
var port = 2124;

app.listen(port, function () {
    console.log('\n\nExample app listening on port '+port)
})


/*app.get('/', function(req, res) {
    res.send('\n\nReturn JSON or HTML View');
});*/

// Q1 - GET /users
app.get('/users', function(req, res) {
    db.run("Select * from users;",function(err, result) {
        res.send(result);
    });
});
/*
// Q2 - GET /users/:id
app.get('/users/:id', function(req, res) {
    let id = req.params.id;
    db.users.find({id: id}, function (err, result) {
        res.send(result)
    });
});

// Q3 - GET /products
app.get('/products', function(req, res) {
    db.run("Select * from products",function(err, result) {
        res.send(result);
    });
});

// Q4 - GET /products/:id
app.get('/products/:id', function(req, res) {
    let id = req.params.id;
    db.products.find({id: id}, function (err, result) {
        res.send(result)
    });
});

// Q5 - GET /purchases
app.get('/purchases', function(req, res) {
    db.run("Select * from purchases",function(err, result) {
        res.send(result);
    });
});

// Q6 - GET /purchases/:id
app.get('/purchases/:id', function(req, res) {
    let id = req.params.id;
    db.purchases.find({id: id}, function (err, result) {
        res.send(result)
    });
});
*/


  
