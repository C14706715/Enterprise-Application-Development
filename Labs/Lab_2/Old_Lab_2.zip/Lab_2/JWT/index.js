var jwt = require('jsonwebtoken');
// sign with RSA SHA256 (i.e. using HMAC256 hashing)
var cert = fs.readFileSync('private.key');  // get private key from disk
var token = jwt.sign({
   sub: 'user:12345',
   iat: Math.floor(Date.now() / 1000)
}, cert, { algorithm: 'RS256'});